function onCreate()
	makeLuaSprite('stupidstage', 'luigis_mansion', -600, -300)
	scaleObject('stupidstage', 1.3, 1.3)
	addLuaSprite('stupidstage', false)
end