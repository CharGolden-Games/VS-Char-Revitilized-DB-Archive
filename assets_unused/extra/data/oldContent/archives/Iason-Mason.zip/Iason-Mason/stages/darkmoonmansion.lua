function onCreate()
	makeLuaSprite('stupidstage', 'luigis_mansion_dark_moon_mansion', -750, -850)
	scaleObject('stupidstage', 1.2, 1.2)
	addLuaSprite('stupidstage', false)
end