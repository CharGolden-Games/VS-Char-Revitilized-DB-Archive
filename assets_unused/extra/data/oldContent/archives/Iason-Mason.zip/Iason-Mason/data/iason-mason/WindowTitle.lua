function onCreatePost()
setPropertyFromClass("openfl.Lib","application.window.title","Friday Night Funkin': VS Char Revitalized | Now Playing | IASON MASON | KennyL")
end
function onDestroy()
setPropertyFromClass("openfl.Lib","application.window.title","Friday Night Funkin': VS Char Revitalized")
end