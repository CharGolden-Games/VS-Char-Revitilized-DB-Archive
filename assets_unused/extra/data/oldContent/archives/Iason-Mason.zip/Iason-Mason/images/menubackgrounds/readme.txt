Put your week backgrounds here!
They must start with "menu_"